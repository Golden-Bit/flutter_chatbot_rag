deploy for E2E test:
flutter build web --release --dart-define=FLUTTER_WEB_DEBUG_SHOW_SEMANTICS=true  