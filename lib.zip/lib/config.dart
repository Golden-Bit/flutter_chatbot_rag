/*
config = {
    "backend_api": "http://34.140.110.56:8095",
    "nlp_api": "http://34.140.110.56:8100",
    "chatbot_nlp_api": "http://34.140.110.56:8080"
}

config = {
    "backend_api": "https://teatek-llm.theia-innovation.com/user-backend",
    "nlp_api": "https://teatek-llm.theia-innovation.com/llm-core",
    "chatbot_nlp_api": "https://teatek-llm.theia-innovation.com/llm-rag"
}
*/

//34.79.136.231